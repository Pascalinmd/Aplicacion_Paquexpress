from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, DECIMAL, Enum, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database.config import Base
import enum

class EstadoPaquete(enum.Enum):
    pendiente = "pendiente"
    en_transito = "en_transito"
    entregado = "entregado"
    cancelado = "cancelado"

class Usuario(Base):
    __tablename__ = "usuarios"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    nombre = Column(String(100), nullable=False)
    apellido = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False, index=True)
    activo = Column(Boolean, default=True)
    fecha_creacion = Column(DateTime, server_default=func.now())
    
    # Relaciones
    paquetes = relationship("Paquete", back_populates="agente")
    entregas = relationship("Entrega", back_populates="agente")

class Paquete(Base):
    __tablename__ = "paquetes"
    
    id = Column(Integer, primary_key=True, index=True)
    numero_rastreo = Column(String(50), unique=True, nullable=False, index=True)
    destinatario = Column(String(200), nullable=False)
    direccion_destino = Column(Text, nullable=False)
    latitud = Column(DECIMAL(10, 8), nullable=True)
    longitud = Column(DECIMAL(11, 8), nullable=True)
    estado = Column(Enum(EstadoPaquete), default=EstadoPaquete.pendiente, nullable=False, index=True)
    agente_id = Column(Integer, ForeignKey("usuarios.id", ondelete="SET NULL"), nullable=True, index=True)
    fecha_creacion = Column(DateTime, server_default=func.now())
    fecha_asignacion = Column(DateTime, nullable=True)
    fecha_entrega = Column(DateTime, nullable=True)
    descripcion = Column(Text, nullable=True)
    peso = Column(DECIMAL(10, 2), nullable=True, comment="Peso en kilogramos")
    
    # Relaciones
    agente = relationship("Usuario", back_populates="paquetes")
    entregas = relationship("Entrega", back_populates="paquete")

class Entrega(Base):
    __tablename__ = "entregas"
    
    id = Column(Integer, primary_key=True, index=True)
    paquete_id = Column(Integer, ForeignKey("paquetes.id", ondelete="CASCADE"), nullable=False, index=True)
    agente_id = Column(Integer, ForeignKey("usuarios.id", ondelete="CASCADE"), nullable=False, index=True)
    fecha_entrega = Column(DateTime, nullable=False, index=True)
    latitud_entrega = Column(DECIMAL(10, 8), nullable=False)
    longitud_entrega = Column(DECIMAL(11, 8), nullable=False)
    foto_evidencia = Column(String(500), nullable=True, comment="Ruta o URL de la foto")
    observaciones = Column(Text, nullable=True)
    fecha_registro = Column(DateTime, server_default=func.now())
    
    # Relaciones
    paquete = relationship("Paquete", back_populates="entregas")
    agente = relationship("Usuario", back_populates="entregas")
