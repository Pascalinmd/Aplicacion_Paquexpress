# 📊 Base de Datos con Datos Abundantes

## Resumen de Cambios

El archivo `schema.sql` ha sido actualizado con una base de datos rica en registros para facilitar las pruebas y desarrollo.

## 📈 Estadísticas de la Base de Datos

### Usuarios (25 agentes)
- **Total:** 25 agentes de entrega
- **Credenciales:** Todos usan la contraseña `password123`
- **Rango:** agente1 hasta agente25
- **Emails:** Formato `nombre.apellido@paquexpress.com`

**Ejemplos de usuarios:**
| Username | Nombre | Apellido | Email |
|----------|--------|----------|-------|
| agente1 | Juan | Pérez | juan.perez@paquexpress.com |
| agente2 | María | González | maria.gonzalez@paquexpress.com |
| agente10 | Valentina | Flores | valentina.flores@paquexpress.com |
| agente20 | Natalia | Reyes | natalia.reyes@paquexpress.com |

### Paquetes (50 paquetes)
- **Total:** 50 paquetes con datos realistas
- **Rango:** PKG001 hasta PKG050
- **Ubicaciones:** Coordenadas GPS reales de Ciudad de México
- **Estados distribuidos:**
  - **Pendiente:** ~28 paquetes
  - **En tránsito:** ~10 paquetes
  - **Entregado:** ~7 paquetes
  - **Sin asignar:** 5 paquetes

**Distribución por agente:**
- Agentes 1-10: 3-4 paquetes cada uno
- Agentes 11-20: 1-3 paquetes cada uno
- Agentes 21-25: Sin paquetes asignados (disponibles)

**Características de los paquetes:**
- Direcciones reales de CDMX (Del Valle, Roma, Condesa, Polanco, etc.)
- Coordenadas GPS precisas (formato DECIMAL 10,8 y 11,8)
- Pesos variados (0.2 kg hasta 25.4 kg)
- Descripciones realistas (Documentos, Electrónicos, Muebles, etc.)

### Entregas (25 entregas completadas)
- **Total:** 25 registros de entregas históricas
- **Periodo:** Últimas 2 semanas
- **Evidencia:** Rutas de fotos simuladas
- **Observaciones:** Comentarios realistas de cada entrega

**Distribución de entregas por agente:**
- Agente 1: 2 entregas
- Agente 2: 2 entregas
- Agente 3: 1 entrega
- Agente 4: 2 entregas
- Agentes 5-19: 1-2 entregas cada uno

## 🗺️ Coordenadas GPS Incluidas

Todas las coordenadas son de ubicaciones reales en Ciudad de México:

| Zona | Ejemplo de Coordenadas | Paquetes |
|------|------------------------|----------|
| Del Valle | 19.3685, -99.1746 | PKG001 |
| Centro Histórico | 19.4336, -99.1377 | PKG006, PKG021 |
| Condesa | 19.4123, -99.1756 | PKG013 |
| Polanco | 19.4278, -99.2104 | PKG007 |
| Iztapalapa | 19.3567, -99.0823 | PKG019 |
| Xochimilco | 19.2845, -99.0234 | PKG016 |

## 🔧 Cómo Usar los Datos

### 1. Inicializar la Base de Datos
```bash
# Desde el directorio backend/
cd backend
python database/init_db.py
```

### 2. Verificar los Datos
El script incluye consultas de verificación al final:
```sql
-- Contar registros por tabla
SELECT 'Usuarios' as Tabla, COUNT(*) as Total FROM usuarios
UNION ALL SELECT 'Paquetes', COUNT(*) FROM paquetes
UNION ALL SELECT 'Entregas', COUNT(*) FROM entregas;
```

**Resultado esperado:**
```
Tabla      | Total
-----------|------
Usuarios   | 25
Paquetes   | 50
Entregas   | 25
```

### 3. Datos para Pruebas

**Login de prueba:**
- Username: `agente1` hasta `agente25`
- Password: `password123`

**Paquetes de prueba para agente1:**
```
PKG001 - Ana López García (Pendiente)
PKG002 - Roberto Martínez Silva (En tránsito)
PKG003 - Laura Fernández Cruz (Pendiente)
PKG004 - Pedro Sánchez Díaz (Pendiente)
```

**Paquetes sin asignar (para asignación manual):**
```
PKG031 - Elena Torres Zamora
PKG032 - Gustavo Maldonado Ortiz
PKG033 - Irene Castillo Vázquez
PKG034 - Oscar Navarro Prieto
PKG035 - Paulina Herrera Castañeda
```

## 📊 Consultas Útiles

### Ver paquetes por estado
```sql
SELECT estado, COUNT(*) as cantidad 
FROM paquetes 
GROUP BY estado;
```

### Ver entregas por agente (Top 10)
```sql
SELECT u.nombre, u.apellido, COUNT(e.id) as entregas_realizadas
FROM usuarios u
LEFT JOIN entregas e ON u.id = e.agente_id
GROUP BY u.id, u.nombre, u.apellido
ORDER BY entregas_realizadas DESC
LIMIT 10;
```

### Ver paquetes pendientes por agente
```sql
SELECT u.nombre, u.apellido, COUNT(p.id) as paquetes_pendientes
FROM usuarios u
LEFT JOIN paquetes p ON u.id = p.agente_id 
  AND p.estado IN ('pendiente', 'en_transito')
GROUP BY u.id, u.nombre, u.apellido
HAVING paquetes_pendientes > 0
ORDER BY paquetes_pendientes DESC;
```

### Ver entregas de la última semana
```sql
SELECT p.numero_rastreo, u.nombre, u.apellido, e.fecha_entrega, e.observaciones
FROM entregas e
JOIN paquetes p ON e.paquete_id = p.id
JOIN usuarios u ON e.agente_id = u.id
WHERE e.fecha_entrega >= DATE_SUB(NOW(), INTERVAL 7 DAY)
ORDER BY e.fecha_entrega DESC;
```

## 🎯 Escenarios de Prueba

### Escenario 1: Agente con múltiples entregas pendientes
- **Login:** agente1 / password123
- **Paquetes:** 4 paquetes asignados (2 pendientes, 2 en tránsito)
- **Prueba:** Completar entregas con foto y GPS

### Escenario 2: Agente nuevo sin paquetes
- **Login:** agente21 / password123
- **Paquetes:** Ninguno asignado
- **Prueba:** Asignar paquetes PKG031-PKG035

### Escenario 3: Revisar historial de entregas
- **Login:** agente3 / password123
- **Entregas completadas:** PKG008 (hace 2 días)
- **Prueba:** Ver historial y evidencias

### Escenario 4: Zona con alta densidad de paquetes
- **Zona:** Centro Histórico (19.43, -99.13)
- **Paquetes:** PKG006, PKG021, PKG031
- **Prueba:** Optimización de rutas

## 🔄 Regenerar Datos

Si necesitas regenerar la base de datos:

```bash
# Opción 1: Ejecutar el script de inicialización
python database/init_db.py

# Opción 2: Ejecutar manualmente el SQL
mysql -u root -p < backend/database/schema.sql
```

## ⚠️ Notas Importantes

1. **Contraseñas:** Todas las contraseñas son `password123` con hash bcrypt
2. **Coordenadas:** Todas son reales de CDMX, precisión 8 decimales
3. **Estados:** Los paquetes entregados tienen fecha_entrega y registro en tabla entregas
4. **Foreign Keys:** Configuradas con CASCADE y SET NULL según lógica de negocio
5. **Índices:** Optimizados para consultas frecuentes (username, estado, agente_id)

## 📱 Uso en Flutter

Al usar estos datos en la app Flutter:
1. Login con cualquier agente (agente1-agente25)
2. Verás los paquetes asignados a ese agente
3. Puedes completar entregas de paquetes pendientes o en tránsito
4. Los paquetes entregados no aparecerán en la lista (filtro backend)

## 🎨 Visualización en Mapa

Todos los paquetes tienen coordenadas GPS válidas, permitiendo:
- Visualizar ubicación de entrega en Google Maps
- Calcular distancia desde ubicación actual
- Mostrar marcadores para cada paquete
- Dibujar rutas optimizadas (feature futuro)

## 📞 Soporte

Si encuentras algún problema con los datos:
1. Verifica que el script init_db.py se ejecutó sin errores
2. Revisa los logs de MySQL
3. Ejecuta las consultas de verificación
4. Regenera la base de datos si es necesario
