from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form
from sqlalchemy.orm import Session
from database.config import get_db
from models.models import Entrega, Paquete, Usuario, EstadoPaquete
from utils.dependencies import get_current_user
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import os
import uuid
import shutil

router = APIRouter(prefix="/api/entregas", tags=["Entregas"])

# Directorio para guardar fotos de evidencia
UPLOAD_DIR = "uploads/evidencias"
os.makedirs(UPLOAD_DIR, exist_ok=True)

class EntregaRequest(BaseModel):
    paquete_id: int
    agente_id: int
    fecha_entrega: str
    latitud_entrega: float
    longitud_entrega: float
    foto_evidencia: Optional[str] = None
    observaciones: Optional[str] = None

class EntregaResponse(BaseModel):
    id: int
    paquete_id: int
    agente_id: int
    fecha_entrega: datetime
    latitud_entrega: float
    longitud_entrega: float
    foto_evidencia: Optional[str]
    observaciones: Optional[str]
    
    class Config:
        from_attributes = True

@router.post("", response_model=EntregaResponse)
async def registrar_entrega(
    request: EntregaRequest,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Registra una nueva entrega de paquete
    
    Crea un registro de entrega con todos los detalles incluyendo
    ubicación GPS y foto de evidencia
    """
    # Verificar que el agente actual sea el que registra la entrega
    if current_user.id != request.agente_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No puede registrar entregas para otro agente"
        )
    
    # Verificar que el paquete existe
    paquete = db.query(Paquete).filter(Paquete.id == request.paquete_id).first()
    if not paquete:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Paquete no encontrado"
        )
    
    # Verificar que el paquete está asignado al agente
    if paquete.agente_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Este paquete no está asignado a usted"
        )
    
    # Verificar que el paquete no ha sido entregado
    if paquete.estado == EstadoPaquete.entregado:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Este paquete ya ha sido entregado"
        )
    
    # Parsear fecha de entrega
    try:
        fecha_entrega = datetime.fromisoformat(request.fecha_entrega.replace('Z', '+00:00'))
    except:
        fecha_entrega = datetime.now()
    
    # Crear registro de entrega
    nueva_entrega = Entrega(
        paquete_id=request.paquete_id,
        agente_id=request.agente_id,
        fecha_entrega=fecha_entrega,
        latitud_entrega=request.latitud_entrega,
        longitud_entrega=request.longitud_entrega,
        foto_evidencia=request.foto_evidencia,
        observaciones=request.observaciones
    )
    
    db.add(nueva_entrega)
    
    # Actualizar estado del paquete
    paquete.estado = EstadoPaquete.entregado
    paquete.fecha_entrega = fecha_entrega
    
    db.commit()
    db.refresh(nueva_entrega)
    
    return EntregaResponse(
        id=nueva_entrega.id,
        paquete_id=nueva_entrega.paquete_id,
        agente_id=nueva_entrega.agente_id,
        fecha_entrega=nueva_entrega.fecha_entrega,
        latitud_entrega=float(nueva_entrega.latitud_entrega),
        longitud_entrega=float(nueva_entrega.longitud_entrega),
        foto_evidencia=nueva_entrega.foto_evidencia,
        observaciones=nueva_entrega.observaciones
    )

@router.post("/upload-foto")
async def subir_foto_evidencia(
    file: UploadFile = File(...),
    paquete_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Sube una foto de evidencia para un paquete
    
    Guarda la imagen en el servidor y devuelve la URL/ruta
    """
    # Verificar que el archivo sea una imagen
    if not file.content_type.startswith('image/'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El archivo debe ser una imagen"
        )
    
    # Verificar que el paquete existe y está asignado al agente
    paquete = db.query(Paquete).filter(Paquete.id == paquete_id).first()
    if not paquete:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Paquete no encontrado"
        )
    
    if paquete.agente_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tiene permiso para subir fotos de este paquete"
        )
    
    # Generar nombre único para el archivo
    file_extension = os.path.splitext(file.filename)[1]
    unique_filename = f"{paquete_id}_{uuid.uuid4()}{file_extension}"
    file_path = os.path.join(UPLOAD_DIR, unique_filename)
    
    # Guardar el archivo
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error al guardar el archivo: {str(e)}"
        )
    
    # Devolver la ruta relativa o URL
    return {
        "filename": unique_filename,
        "url": f"/uploads/evidencias/{unique_filename}",
        "message": "Foto subida correctamente"
    }
