from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database.config import get_db
from models.models import Paquete, Usuario, EstadoPaquete
from utils.dependencies import get_current_user
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from decimal import Decimal

router = APIRouter(prefix="/api/paquetes", tags=["Paquetes"])

class PaqueteResponse(BaseModel):
    id: int
    numero_rastreo: str
    destinatario: str
    direccion_destino: str
    latitud: Optional[float]
    longitud: Optional[float]
    estado: str
    agente_id: Optional[int]
    fecha_asignacion: Optional[datetime]
    fecha_entrega: Optional[datetime]
    descripcion: Optional[str]
    peso: Optional[float]
    
    class Config:
        from_attributes = True

class ActualizarEstadoRequest(BaseModel):
    estado: str

@router.get("/agente/{agente_id}", response_model=List[PaqueteResponse])
async def obtener_paquetes_agente(
    agente_id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Obtiene todos los paquetes asignados a un agente específico
    
    Solo muestra paquetes pendientes y en tránsito
    """
    # Verificar que el agente actual solo pueda ver sus propios paquetes
    # (o permitir a administradores ver todos)
    if current_user.id != agente_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tiene permiso para ver los paquetes de otro agente"
        )
    
    paquetes = db.query(Paquete).filter(
        Paquete.agente_id == agente_id,
        Paquete.estado.in_([EstadoPaquete.pendiente, EstadoPaquete.en_transito])
    ).order_by(Paquete.fecha_asignacion.desc()).all()
    
    return [
        PaqueteResponse(
            id=p.id,
            numero_rastreo=p.numero_rastreo,
            destinatario=p.destinatario,
            direccion_destino=p.direccion_destino,
            latitud=float(p.latitud) if p.latitud else None,
            longitud=float(p.longitud) if p.longitud else None,
            estado=p.estado.value,
            agente_id=p.agente_id,
            fecha_asignacion=p.fecha_asignacion,
            fecha_entrega=p.fecha_entrega,
            descripcion=p.descripcion,
            peso=float(p.peso) if p.peso else None
        )
        for p in paquetes
    ]

@router.get("/{paquete_id}", response_model=PaqueteResponse)
async def obtener_paquete(
    paquete_id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Obtiene la información de un paquete específico
    """
    paquete = db.query(Paquete).filter(Paquete.id == paquete_id).first()
    
    if not paquete:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Paquete no encontrado"
        )
    
    # Verificar que el agente tenga acceso a este paquete
    if paquete.agente_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tiene permiso para ver este paquete"
        )
    
    return PaqueteResponse(
        id=paquete.id,
        numero_rastreo=paquete.numero_rastreo,
        destinatario=paquete.destinatario,
        direccion_destino=paquete.direccion_destino,
        latitud=float(paquete.latitud) if paquete.latitud else None,
        longitud=float(paquete.longitud) if paquete.longitud else None,
        estado=paquete.estado.value,
        agente_id=paquete.agente_id,
        fecha_asignacion=paquete.fecha_asignacion,
        fecha_entrega=paquete.fecha_entrega,
        descripcion=paquete.descripcion,
        peso=float(paquete.peso) if paquete.peso else None
    )

@router.put("/{paquete_id}/estado")
async def actualizar_estado_paquete(
    paquete_id: int,
    request: ActualizarEstadoRequest,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user)
):
    """
    Actualiza el estado de un paquete
    """
    paquete = db.query(Paquete).filter(Paquete.id == paquete_id).first()
    
    if not paquete:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Paquete no encontrado"
        )
    
    # Verificar permisos
    if paquete.agente_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tiene permiso para modificar este paquete"
        )
    
    # Validar el estado
    try:
        nuevo_estado = EstadoPaquete(request.estado)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Estado inválido. Estados válidos: {[e.value for e in EstadoPaquete]}"
        )
    
    # Actualizar estado
    paquete.estado = nuevo_estado
    
    # Si se marca como entregado, registrar fecha de entrega
    if nuevo_estado == EstadoPaquete.entregado:
        paquete.fecha_entrega = datetime.now()
    
    db.commit()
    
    return {"message": "Estado actualizado correctamente", "nuevo_estado": nuevo_estado.value}
