"""
Script para inicializar la base de datos con el esquema y datos de prueba
"""
import pymysql
import os
from dotenv import load_dotenv

load_dotenv()

# Configuración
MYSQL_USER = os.getenv('MYSQL_USER', 'root')
MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD', '')
MYSQL_HOST = os.getenv('MYSQL_HOST', 'localhost')
MYSQL_PORT = int(os.getenv('MYSQL_PORT', '3306'))

def init_database():
    """Inicializa la base de datos ejecutando el script SQL"""
    try:
        # Conectar a MySQL sin especificar base de datos
        connection = pymysql.connect(
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            charset='utf8mb4'
        )
        
        print("✓ Conectado a MySQL")
        
        # Leer el script SQL
        script_path = os.path.join(os.path.dirname(__file__), 'schema.sql')
        with open(script_path, 'r', encoding='utf-8') as file:
            sql_script = file.read()
        
        # Ejecutar cada statement
        cursor = connection.cursor()
        
        # Dividir por punto y coma para ejecutar cada comando
        statements = [stmt.strip() for stmt in sql_script.split(';') if stmt.strip()]
        
        for statement in statements:
            try:
                cursor.execute(statement)
                connection.commit()
            except Exception as e:
                print(f"Error en statement: {str(e)[:100]}")
                continue
        
        print("✓ Base de datos inicializada correctamente")
        print("✓ Tablas creadas")
        print("✓ Datos de prueba insertados")
        print("\nUsuarios de prueba:")
        print("  - Usuario: agente1 / Contraseña: password123")
        print("  - Usuario: agente2 / Contraseña: password123")
        print("  - Usuario: agente3 / Contraseña: password123")
        
        cursor.close()
        connection.close()
        
    except Exception as e:
        print(f"✗ Error al inicializar la base de datos: {e}")
        return False
    
    return True

if __name__ == "__main__":
    print("Iniciando configuración de base de datos...")
    print(f"Host: {MYSQL_HOST}")
    print(f"Usuario: {MYSQL_USER}")
    print("-" * 50)
    
    if init_database():
        print("\n¡Listo! La base de datos está configurada y lista para usar.")
    else:
        print("\nHubo errores durante la configuración.")
