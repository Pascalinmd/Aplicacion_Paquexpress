-- ================================================
-- PAQUEXPRESS - ESQUEMA DE BASE DE DATOS
-- Sistema de Entregas con datos de prueba abundantes
-- ================================================

-- Crear base de datos si no existe
CREATE DATABASE IF NOT EXISTS paquexpress_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE paquexpress_db;

-- ================================================
-- TABLA: usuarios
-- Descripción: Almacena información de los agentes de entrega
-- ================================================
DROP TABLE IF EXISTS entregas;
DROP TABLE IF EXISTS paquetes;
DROP TABLE IF EXISTS usuarios;

CREATE TABLE usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_activo (activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- TABLA: paquetes
-- Descripción: Almacena información de los paquetes a entregar
-- ================================================
CREATE TABLE paquetes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    numero_rastreo VARCHAR(50) UNIQUE NOT NULL,
    destinatario VARCHAR(200) NOT NULL,
    direccion_destino TEXT NOT NULL,
    latitud DECIMAL(10, 8) NULL,
    longitud DECIMAL(11, 8) NULL,
    estado ENUM('pendiente', 'en_transito', 'entregado', 'cancelado') DEFAULT 'pendiente' NOT NULL,
    agente_id INT NULL,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_asignacion DATETIME NULL,
    fecha_entrega DATETIME NULL,
    descripcion TEXT NULL,
    peso DECIMAL(10, 2) NULL COMMENT 'Peso en kilogramos',
    FOREIGN KEY (agente_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    INDEX idx_numero_rastreo (numero_rastreo),
    INDEX idx_estado (estado),
    INDEX idx_agente_id (agente_id),
    INDEX idx_fecha_creacion (fecha_creacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- TABLA: entregas
-- Descripción: Registros de entregas completadas con evidencia
-- ================================================
CREATE TABLE entregas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    paquete_id INT NOT NULL,
    agente_id INT NOT NULL,
    fecha_entrega DATETIME NOT NULL,
    latitud_entrega DECIMAL(10, 8) NOT NULL,
    longitud_entrega DECIMAL(11, 8) NOT NULL,
    foto_evidencia VARCHAR(500) NULL COMMENT 'Ruta o URL de la foto',
    observaciones TEXT NULL,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (paquete_id) REFERENCES paquetes(id) ON DELETE CASCADE,
    FOREIGN KEY (agente_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_paquete_id (paquete_id),
    INDEX idx_agente_id (agente_id),
    INDEX idx_fecha_entrega (fecha_entrega)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================
-- INSERCIÓN DE DATOS - USUARIOS (25 agentes)
-- Contraseña para todos: password123
-- Hash bcrypt: $2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2
-- ================================================
INSERT INTO usuarios (username, password_hash, nombre, apellido, email, activo) VALUES
('agente1', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Juan', 'Pérez', 'juan.perez@paquexpress.com', TRUE),
('agente2', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'María', 'González', 'maria.gonzalez@paquexpress.com', TRUE),
('agente3', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Carlos', 'Rodríguez', 'carlos.rodriguez@paquexpress.com', TRUE),
('agente4', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Ana', 'Martínez', 'ana.martinez@paquexpress.com', TRUE),
('agente5', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Luis', 'Hernández', 'luis.hernandez@paquexpress.com', TRUE),
('agente6', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Laura', 'López', 'laura.lopez@paquexpress.com', TRUE),
('agente7', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Pedro', 'García', 'pedro.garcia@paquexpress.com', TRUE),
('agente8', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Sofía', 'Ramírez', 'sofia.ramirez@paquexpress.com', TRUE),
('agente9', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Diego', 'Torres', 'diego.torres@paquexpress.com', TRUE),
('agente10', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Valentina', 'Flores', 'valentina.flores@paquexpress.com', TRUE),
('agente11', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Fernando', 'Sánchez', 'fernando.sanchez@paquexpress.com', TRUE),
('agente12', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Carmen', 'Vargas', 'carmen.vargas@paquexpress.com', TRUE),
('agente13', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Roberto', 'Castro', 'roberto.castro@paquexpress.com', TRUE),
('agente14', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Patricia', 'Morales', 'patricia.morales@paquexpress.com', TRUE),
('agente15', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Andrés', 'Ortiz', 'andres.ortiz@paquexpress.com', TRUE),
('agente16', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Gabriela', 'Ruiz', 'gabriela.ruiz@paquexpress.com', TRUE),
('agente17', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Miguel', 'Jiménez', 'miguel.jimenez@paquexpress.com', TRUE),
('agente18', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Isabel', 'Méndez', 'isabel.mendez@paquexpress.com', TRUE),
('agente19', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Javier', 'Cruz', 'javier.cruz@paquexpress.com', TRUE),
('agente20', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Natalia', 'Reyes', 'natalia.reyes@paquexpress.com', TRUE),
('agente21', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Ricardo', 'Gutiérrez', 'ricardo.gutierrez@paquexpress.com', TRUE),
('agente22', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Daniela', 'Herrera', 'daniela.herrera@paquexpress.com', TRUE),
('agente23', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Alejandro', 'Medina', 'alejandro.medina@paquexpress.com', TRUE),
('agente24', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Camila', 'Romero', 'camila.romero@paquexpress.com', TRUE),
('agente25', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5LS3JqK3ybYQ2', 'Sebastián', 'Navarro', 'sebastian.navarro@paquexpress.com', TRUE);

-- ================================================
-- INSERCIÓN DE DATOS - PAQUETES (50 paquetes)
-- Estados: pendiente, en_transito, entregado
-- Coordenadas GPS de Ciudad de México y área metropolitana
-- ================================================
INSERT INTO paquetes (numero_rastreo, destinatario, direccion_destino, latitud, longitud, estado, agente_id, fecha_asignacion, descripcion, peso) VALUES
-- Paquetes asignados al agente1 (pendientes)
('PKG001', 'Ana López García', 'Av. Insurgentes Sur 1234, Col. Del Valle, CDMX', 19.36854900, -99.17464800, 'pendiente', 1, NOW(), 'Documentos importantes', 0.5),
('PKG002', 'Roberto Martínez Silva', 'Calle Reforma 567, Col. Cuauhtémoc, CDMX', 19.43262000, -99.14122400, 'en_transito', 1, NOW(), 'Electrónicos', 2.3),
('PKG003', 'Laura Fernández Cruz', 'Av. Universidad 890, Col. Copilco, CDMX', 19.33609800, -99.17744600, 'pendiente', 1, NOW(), 'Libros y material educativo', 3.5),
('PKG004', 'Pedro Sánchez Díaz', 'Calzada de Tlalpan 2345, Col. Portales, CDMX', 19.36267000, -99.14234500, 'pendiente', 1, NOW(), 'Ropa y accesorios', 1.8),

-- Paquetes asignados al agente2 (mixtos)
('PKG005', 'Claudia Ramírez Soto', 'Av. Revolución 456, Col. San Ángel, CDMX', 19.35183200, -99.19108900, 'pendiente', 2, NOW(), 'Juguetes', 2.1),
('PKG006', 'José Luis Torres Méndez', 'Calle Madero 123, Centro Histórico, CDMX', 19.43364300, -99.13778900, 'en_transito', 2, NOW(), 'Artículos de oficina', 1.2),
('PKG007', 'María Elena Vargas Ortiz', 'Av. Patriotismo 789, Col. San Pedro de los Pinos, CDMX', 19.38563400, -99.18773200, 'pendiente', 2, NOW(), 'Productos de belleza', 0.8),

-- Paquetes asignados al agente3 (varios estados)
('PKG008', 'Fernando Castro Reyes', 'Circuito Interior 345, Col. Nápoles, CDMX', 19.39156700, -99.17989100, 'entregado', 3, DATE_SUB(NOW(), INTERVAL 2 DAY), 'Equipo deportivo', 4.5),
('PKG009', 'Gabriela Moreno Paz', 'Viaducto Miguel Alemán 678, Col. Piedad Narvarte, CDMX', 19.39823400, -99.15689700, 'pendiente', 3, NOW(), 'Alimentos no perecederos', 5.2),
('PKG010', 'Ricardo Herrera Luna', 'Av. División del Norte 901, Col. Narvarte, CDMX', 19.39145600, -99.15034500, 'en_transito', 3, NOW(), 'Herramientas', 6.3),

-- Paquetes asignados al agente4
('PKG011', 'Sofía Jiménez Vega', 'Eje Central 234, Col. Doctores, CDMX', 19.42345600, -99.14567800, 'pendiente', 4, NOW(), 'Medicamentos', 0.3),
('PKG012', 'Antonio Guzmán Flores', 'Av. Chapultepec 456, Col. Roma Norte, CDMX', 19.41678900, -99.16234500, 'pendiente', 4, NOW(), 'Accesorios para celular', 0.4),
('PKG013', 'Verónica Campos Ruiz', 'Calle Ámsterdam 789, Col. Condesa, CDMX', 19.41234500, -99.17567800, 'en_transito', 4, NOW(), 'Artículos de decoración', 2.8),

-- Paquetes asignados al agente5
('PKG014', 'Eduardo Montes Salas', 'Av. Observatorio 1122, Col. Tacubaya, CDMX', 19.40123400, -99.18876500, 'pendiente', 5, NOW(), 'Repuestos automotrices', 3.7),
('PKG015', 'Paola Ramos Cortés', 'Periférico Sur 3344, Col. Jardines del Pedregal, CDMX', 19.32456700, -99.19234500, 'pendiente', 5, NOW(), 'Plantas y macetas', 4.1),
('PKG016', 'Héctor Silva Domínguez', 'Av. Tláhuac 5566, Col. La Asunción, CDMX', 19.28567800, -99.02345600, 'entregado', 5, DATE_SUB(NOW(), INTERVAL 1 DAY), 'Alimentos congelados', 8.5),

-- Paquetes asignados al agente6
('PKG017', 'Diana Ortega Salazar', 'Calz. de la Viga 778, Col. Transito, CDMX', 19.38765400, -99.11234500, 'pendiente', 6, NOW(), 'Artículos para mascotas', 2.9),
('PKG018', 'Manuel Delgado Aguilar', 'Av. Canal de Miramontes 990, Col. Coapa, CDMX', 19.29876500, -99.13567800, 'pendiente', 6, NOW(), 'Videojuegos', 0.6),
('PKG019', 'Adriana Rojas Paredes', 'Eje 5 Sur 1223, Col. Iztapalapa, CDMX', 19.35678900, -99.08234500, 'en_transito', 6, NOW(), 'Ropa deportiva', 1.5),

-- Paquetes asignados al agente7
('PKG020', 'Jorge Peña Téllez', 'Av. Río Churubusco 3445, Col. Granjas México, CDMX', 19.39234500, -99.08765400, 'pendiente', 7, NOW(), 'Equipo de cómputo', 5.8),
('PKG021', 'Mónica Ávila Santos', 'Calle 16 de Septiembre 6677, Col. Centro, CDMX', 19.43456700, -99.13456700, 'entregado', 7, DATE_SUB(NOW(), INTERVAL 3 DAY), 'Joyería', 0.2),
('PKG022', 'Luis Alberto Núñez Gómez', 'Av. Aztecas 8899, Col. Ajusco, CDMX', 19.23456700, -99.19876500, 'pendiente', 7, NOW(), 'Muebles pequeños', 12.3),

-- Paquetes asignados al agente8
('PKG023', 'Carolina Mendoza Ibarra', 'Autopista México-Puebla km 15, Col. Los Reyes, CDMX', 19.35987600, -99.01234500, 'pendiente', 8, NOW(), 'Productos químicos', 7.2),
('PKG024', 'Sergio Bravo Cervantes', 'Av. Politécnico 1011, Col. Lindavista, CDMX', 19.48765400, -99.12345600, 'pendiente', 8, NOW(), 'Material de construcción', 15.6),
('PKG025', 'Lorena Cervantes Ríos', 'Calz. Ticomán 1213, Col. San Juan de Aragón, CDMX', 19.47234500, -99.08876500, 'en_transito', 8, NOW(), 'Instrumentos musicales', 3.4),

-- Paquetes asignados al agente9
('PKG026', 'Raúl Padilla Ochoa', 'Av. Central 1415, Col. Tlatelolco, CDMX', 19.45123400, -99.14567800, 'pendiente', 9, NOW(), 'Libros antiguos', 2.7),
('PKG027', 'Mariana Quintero León', 'Eje 4 Norte 1617, Col. Magdalena de las Salinas, CDMX', 19.47876500, -99.11234500, 'pendiente', 9, NOW(), 'Artesanías', 1.9),
('PKG028', 'Arturo Fuentes Carrillo', 'Av. Eduardo Molina 1819, Col. Moctezuma, CDMX', 19.44567800, -99.09876500, 'entregado', 9, DATE_SUB(NOW(), INTERVAL 1 DAY), 'Electrodomésticos', 18.5),

-- Paquetes asignados al agente10
('PKG029', 'Beatriz Sandoval Mejía', 'Calz. Ignacio Zaragoza 2021, Col. Agrícola Oriental, CDMX', 19.40234500, -99.05678900, 'pendiente', 10, NOW(), 'Productos orgánicos', 3.1),
('PKG030', 'Cristian Valdez Ponce', 'Av. Texcoco 2223, Col. Santa Martha Acatitla, CDMX', 19.36789000, -98.99234500, 'pendiente', 10, NOW(), 'Material didáctico', 2.4),

-- Paquetes sin asignar (disponibles para asignación)
('PKG031', 'Elena Torres Zamora', 'Calle Durango 2425, Col. Roma Sur, CDMX', 19.40678900, -99.16789000, 'pendiente', NULL, NULL, 'Perfumes importados', 0.5),
('PKG032', 'Gustavo Maldonado Ortiz', 'Av. Cuauhtémoc 2627, Col. Santa Cruz Atoyac, CDMX', 19.38234500, -99.17456700, 'pendiente', NULL, NULL, 'Productos electrónicos', 4.2),
('PKG033', 'Irene Castillo Vázquez', 'Calle Colima 2829, Col. Roma Norte, CDMX', 19.41567800, -99.16123400, 'pendiente', NULL, NULL, 'Ropa de diseñador', 1.3),
('PKG034', 'Oscar Navarro Prieto', 'Av. Cuauhtémoc 3031, Col. Narvarte Poniente, CDMX', 19.39876500, -99.15567800, 'pendiente', NULL, NULL, 'Zapatos', 2.1),
('PKG035', 'Paulina Herrera Castañeda', 'Eje Central 3233, Col. Obrera, CDMX', 19.41234500, -99.14789000, 'pendiente', NULL, NULL, 'Accesorios de moda', 0.8),

-- Más paquetes distribuidos entre agentes 11-20
('PKG036', 'Samuel Lara Méndez', 'Av. México-Tacuba 3435, Col. Popotla, CDMX', 19.45678900, -99.17234500, 'pendiente', 11, NOW(), 'Suministros industriales', 9.4),
('PKG037', 'Teresa Mora Villalobos', 'Calle Norte 45, Col. Moctezuma 2da Sección, CDMX', 19.43123400, -99.09456700, 'en_transito', 11, NOW(), 'Productos farmacéuticos', 1.7),
('PKG038', 'Ulises Parra Esquivel', 'Av. 608 3839, Col. San Juan de Aragón, CDMX', 19.46789000, -99.08123400, 'entregado', 12, DATE_SUB(NOW(), INTERVAL 2 DAY), 'Documentación legal', 0.4),
('PKG039', 'Vanessa Cortés Luna', 'Calle Oriente 172, Col. Moctezuma, CDMX', 19.44234500, -99.09789000, 'pendiente', 12, NOW(), 'Material escolar', 3.6),
('PKG040', 'Walter Romero Aguilera', 'Av. 602 4243, Col. San Juan de Aragón, CDMX', 19.47456700, -99.07567800, 'pendiente', 13, NOW(), 'Equipamiento médico', 11.2),

-- Paquetes para agentes 14-20
('PKG041', 'Ximena Guevara Salinas', 'Calz. de Guadalupe 4445, Col. Industrial, CDMX', 19.49234500, -99.11678900, 'pendiente', 14, NOW(), 'Textiles', 5.8),
('PKG042', 'Yolanda Soto Ramírez', 'Av. Instituto Politécnico Nacional 4647, Col. Zacatenco, CDMX', 19.50456700, -99.13234500, 'en_transito', 14, NOW(), 'Equipo de laboratorio', 8.7),
('PKG043', 'Zacarías Bautista Flores', 'Calz. Vallejo 4849, Col. Vallejo, CDMX', 19.48789000, -99.15678900, 'entregado', 15, DATE_SUB(NOW(), INTERVAL 1 DAY), 'Herramientas eléctricas', 7.3),
('PKG044', 'Andrea Campos Solís', 'Eje 5 Norte 5051, Col. Guadalupe Tepeyac, CDMX', 19.48123400, -99.13789000, 'pendiente', 15, NOW(), 'Productos de limpieza', 6.1),
('PKG045', 'Bernardo Estrada Montes', 'Av. Insurgentes Norte 5253, Col. Santa María la Ribera, CDMX', 19.44678900, -99.15234500, 'pendiente', 16, NOW(), 'Antigüedades', 4.9),
('PKG046', 'Cecilia Franco Díaz', 'Calz. San Simón 5455, Col. San Rafael, CDMX', 19.44234500, -99.15789000, 'pendiente', 17, NOW(), 'Artículos religiosos', 1.4),
('PKG047', 'Damián Gallardo Peña', 'Av. Ejército Nacional 5657, Col. Granada, CDMX', 19.43567800, -99.19234500, 'en_transito', 18, NOW(), 'Equipo de oficina', 12.8),
('PKG048', 'Esmeralda Hidalgo Cruz', 'Paseo de la Reforma 5859, Col. Lomas de Chapultepec, CDMX', 19.42789000, -99.21456700, 'entregado', 19, DATE_SUB(NOW(), INTERVAL 3 DAY), 'Arte y cuadros', 8.9),
('PKG049', 'Fabián Iglesias Torres', 'Av. Constituyentes 6061, Col. Lomas Altas, CDMX', 19.41234500, -99.23678900, 'pendiente', 20, NOW(), 'Muebles de lujo', 25.4),
('PKG050', 'Gisela Juárez Vargas', 'Periférico Sur 6263, Col. Insurgentes Cuicuilco, CDMX', 19.30456700, -99.18123400, 'pendiente', 20, NOW(), 'Productos gourmet', 3.8);

-- ================================================
-- INSERCIÓN DE DATOS - ENTREGAS (25 entregas completadas)
-- Registros de entregas realizadas con evidencia
-- ================================================
INSERT INTO entregas (paquete_id, agente_id, fecha_entrega, latitud_entrega, longitud_entrega, foto_evidencia, observaciones) VALUES
-- Entregas del agente3
(8, 3, DATE_SUB(NOW(), INTERVAL 2 DAY), 19.39156700, -99.17989100, 'evidencias/PKG008_evidence.jpg', 'Entrega exitosa. Cliente satisfecho con el producto.'),

-- Entregas del agente5
(16, 5, DATE_SUB(NOW(), INTERVAL 1 DAY), 19.28567800, -99.02345600, 'evidencias/PKG016_evidence.jpg', 'Paquete entregado en buen estado. Se requirió refrigeración.'),

-- Entregas del agente7
(21, 7, DATE_SUB(NOW(), INTERVAL 3 DAY), 19.43456700, -99.13456700, 'evidencias/PKG021_evidence.jpg', 'Cliente firmó recibido. Contenido verificado.'),

-- Entregas del agente9
(28, 9, DATE_SUB(NOW(), INTERVAL 1 DAY), 19.44567800, -99.09876500, 'evidencias/PKG028_evidence.jpg', 'Electrodoméstico en perfectas condiciones. Instalación no requerida.'),

-- Entregas del agente12
(38, 12, DATE_SUB(NOW(), INTERVAL 2 DAY), 19.46789000, -99.08123400, 'evidencias/PKG038_evidence.jpg', 'Documentos entregados en sobre sellado. Cliente verificó contenido.'),

-- Entregas del agente15
(43, 15, DATE_SUB(NOW(), INTERVAL 1 DAY), 19.48789000, -99.15678900, 'evidencias/PKG043_evidence.jpg', 'Herramientas en excelente estado. Cliente probó funcionamiento.'),

-- Entregas del agente19
(48, 19, DATE_SUB(NOW(), INTERVAL 3 DAY), 19.42789000, -99.21456700, 'evidencias/PKG048_evidence.jpg', 'Arte entregado con empaque especial. Cliente muy satisfecho.'),

-- Entregas adicionales de hace 1 semana (18 más)
(1, 1, DATE_SUB(NOW(), INTERVAL 7 DAY), 19.36854900, -99.17464800, 'evidencias/PKG001_old_evidence.jpg', 'Entrega anterior - Documentos urgentes'),
(2, 1, DATE_SUB(NOW(), INTERVAL 6 DAY), 19.43262000, -99.14122400, 'evidencias/PKG002_old_evidence.jpg', 'Entrega anterior - Dispositivo electrónico funcional'),
(5, 2, DATE_SUB(NOW(), INTERVAL 8 DAY), 19.35183200, -99.19108900, 'evidencias/PKG005_old_evidence.jpg', 'Entrega anterior - Juguetes empacados correctamente'),
(6, 2, DATE_SUB(NOW(), INTERVAL 5 DAY), 19.43364300, -99.13778900, 'evidencias/PKG006_old_evidence.jpg', 'Entrega anterior - Material de oficina completo'),
(11, 4, DATE_SUB(NOW(), INTERVAL 9 DAY), 19.42345600, -99.14567800, 'evidencias/PKG011_old_evidence.jpg', 'Entrega anterior - Medicamentos controlados entregados'),
(12, 4, DATE_SUB(NOW(), INTERVAL 4 DAY), 19.41678900, -99.16234500, 'evidencias/PKG012_old_evidence.jpg', 'Entrega anterior - Accesorios verificados'),
(17, 6, DATE_SUB(NOW(), INTERVAL 10 DAY), 19.38765400, -99.11234500, 'evidencias/PKG017_old_evidence.jpg', 'Entrega anterior - Productos para mascotas'),
(18, 6, DATE_SUB(NOW(), INTERVAL 7 DAY), 19.29876500, -99.13567800, 'evidencias/PKG018_old_evidence.jpg', 'Entrega anterior - Videojuegos nuevos'),
(23, 8, DATE_SUB(NOW(), INTERVAL 11 DAY), 19.35987600, -99.01234500, 'evidencias/PKG023_old_evidence.jpg', 'Entrega anterior - Productos químicos con precaución'),
(24, 8, DATE_SUB(NOW(), INTERVAL 6 DAY), 19.48765400, -99.12345600, 'evidencias/PKG024_old_evidence.jpg', 'Entrega anterior - Material pesado descargado'),
(26, 9, DATE_SUB(NOW(), INTERVAL 8 DAY), 19.45123400, -99.14567800, 'evidencias/PKG026_old_evidence.jpg', 'Entrega anterior - Libros en buen estado'),
(29, 10, DATE_SUB(NOW(), INTERVAL 9 DAY), 19.40234500, -99.05678900, 'evidencias/PKG029_old_evidence.jpg', 'Entrega anterior - Productos orgánicos frescos'),
(30, 10, DATE_SUB(NOW(), INTERVAL 5 DAY), 19.36789000, -98.99234500, 'evidencias/PKG030_old_evidence.jpg', 'Entrega anterior - Material didáctico completo'),
(36, 11, DATE_SUB(NOW(), INTERVAL 12 DAY), 19.45678900, -99.17234500, 'evidencias/PKG036_old_evidence.jpg', 'Entrega anterior - Suministros industriales pesados'),
(37, 11, DATE_SUB(NOW(), INTERVAL 4 DAY), 19.43123400, -99.09456700, 'evidencias/PKG037_old_evidence.jpg', 'Entrega anterior - Productos farmacéuticos controlados'),
(39, 12, DATE_SUB(NOW(), INTERVAL 10 DAY), 19.44234500, -99.09789000, 'evidencias/PKG039_old_evidence.jpg', 'Entrega anterior - Material escolar variado'),
(40, 13, DATE_SUB(NOW(), INTERVAL 7 DAY), 19.47456700, -99.07567800, 'evidencias/PKG040_old_evidence.jpg', 'Entrega anterior - Equipamiento médico delicado'),
(41, 14, DATE_SUB(NOW(), INTERVAL 11 DAY), 19.49234500, -99.11678900, 'evidencias/PKG041_old_evidence.jpg', 'Entrega anterior - Textiles de calidad'),
(42, 14, DATE_SUB(NOW(), INTERVAL 6 DAY), 19.50456700, -99.13234500, 'evidencias/PKG042_old_evidence.jpg', 'Entrega anterior - Equipo de laboratorio preciso');

-- ================================================
-- CONSULTAS DE VERIFICACIÓN
-- ================================================

-- Contar registros por tabla
SELECT 'Usuarios' as Tabla, COUNT(*) as Total FROM usuarios
UNION ALL
SELECT 'Paquetes', COUNT(*) FROM paquetes
UNION ALL
SELECT 'Entregas', COUNT(*) FROM entregas;

-- Paquetes por estado
SELECT estado, COUNT(*) as cantidad FROM paquetes GROUP BY estado;

-- Entregas por agente (Top 10)
SELECT 
    u.nombre,
    u.apellido,
    COUNT(e.id) as entregas_realizadas
FROM usuarios u
LEFT JOIN entregas e ON u.id = e.agente_id
GROUP BY u.id, u.nombre, u.apellido
ORDER BY entregas_realizadas DESC
LIMIT 10;

-- Paquetes pendientes por agente
SELECT 
    u.nombre,
    u.apellido,
    COUNT(p.id) as paquetes_pendientes
FROM usuarios u
LEFT JOIN paquetes p ON u.id = p.agente_id AND p.estado IN ('pendiente', 'en_transito')
GROUP BY u.id, u.nombre, u.apellido
HAVING paquetes_pendientes > 0
ORDER BY paquetes_pendientes DESC;

-- ================================================
-- FIN DEL SCRIPT
-- ================================================
