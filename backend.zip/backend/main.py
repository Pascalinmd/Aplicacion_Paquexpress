from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from routes import auth, paquetes, entregas
import os

# Crear la aplicación FastAPI
app = FastAPI(
    title="Paquexpress API",
    description="API REST para el sistema de entregas de Paquexpress S.A. de C.V.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configurar CORS para permitir peticiones desde Flutter
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # En producción, especificar dominios permitidos
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Montar directorio de archivos estáticos para las fotos de evidencia
os.makedirs("uploads/evidencias", exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Incluir routers
app.include_router(auth.router)
app.include_router(paquetes.router)
app.include_router(entregas.router)

# Ruta raíz
@app.get("/")
async def root():
    return {
        "message": "Bienvenido a Paquexpress API",
        "version": "1.0.0",
        "docs": "/docs",
        "redoc": "/redoc"
    }

# Ruta de health check
@app.get("/health")
async def health_check():
    return {
        "status": "ok",
        "service": "Paquexpress API"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
