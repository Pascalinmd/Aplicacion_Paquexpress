# Backend API para Paquexpress

## Descripción
API REST desarrollada con FastAPI para el sistema de entregas de Paquexpress S.A. de C.V.

## Tecnologías
- Python 3.9+
- FastAPI
- MySQL
- SQLAlchemy
- Passlib (para encriptación de contraseñas)
- JWT (para autenticación)

## Instalación

### Requisitos previos
- Python 3.9 o superior
- MySQL Server
- pip

### Pasos de instalación

1. Navegar a la carpeta del backend:
```bash
cd backend
```

2. Crear un entorno virtual:
```bash
python -m venv venv
```

3. Activar el entorno virtual:
- Windows:
```bash
venv\Scripts\activate
```
- Linux/Mac:
```bash
source venv/bin/activate
```

4. Instalar dependencias:
```bash
pip install -r requirements.txt
```

5. Configurar la base de datos:
- Crear una base de datos en MySQL llamada `paquexpress_db`
- Actualizar las credenciales en `database/config.py` si es necesario

6. Ejecutar el script de inicialización de la base de datos:
```bash
python database/init_db.py
```

## Ejecución

Desde la carpeta `backend`:

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

La API estará disponible en: http://localhost:8000

Documentación interactiva (Swagger): http://localhost:8000/docs

## Estructura de carpetas

```
backend/
├── main.py                 # Punto de entrada de la aplicación
├── requirements.txt        # Dependencias de Python
├── database/
│   ├── config.py          # Configuración de la base de datos
│   ├── init_db.py         # Script de inicialización
│   └── schema.sql         # Esquema SQL
├── models/
│   └── models.py          # Modelos SQLAlchemy
├── routes/
│   ├── auth.py            # Rutas de autenticación
│   ├── paquetes.py        # Rutas de paquetes
│   └── entregas.py        # Rutas de entregas
└── utils/
    ├── security.py        # Utilidades de seguridad
    └── dependencies.py    # Dependencias compartidas
```

## Endpoints principales

### Autenticación
- `POST /api/auth/login` - Iniciar sesión

### Paquetes
- `GET /api/paquetes/agente/{agente_id}` - Obtener paquetes asignados
- `GET /api/paquetes/{paquete_id}` - Obtener un paquete específico
- `PUT /api/paquetes/{paquete_id}/estado` - Actualizar estado del paquete

### Entregas
- `POST /api/entregas` - Registrar una entrega
- `POST /api/entregas/upload-foto` - Subir foto de evidencia

## Usuarios de prueba

Usuario: `agente1`
Contraseña: `password123`

Usuario: `agente2`
Contraseña: `password123`
