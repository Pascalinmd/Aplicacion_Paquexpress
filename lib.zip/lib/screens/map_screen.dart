import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../models/paquete.dart';

class MapScreen extends StatefulWidget {
  final Paquete paquete;
  final Position? ubicacionActual;

  const MapScreen({
    super.key,
    required this.paquete,
    this.ubicacionActual,
  });

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  double? _distancia;

  @override
  void initState() {
    super.initState();
    _crearMarkers();
    _calcularDistancia();
  }

  void _crearMarkers() {
    final markers = <Marker>{};

    // Marker del destino
    if (widget.paquete.latitud != null && widget.paquete.longitud != null) {
      markers.add(
        Marker(
          markerId: const MarkerId('destino'),
          position: LatLng(
            widget.paquete.latitud!,
            widget.paquete.longitud!,
          ),
          infoWindow: InfoWindow(
            title: 'Destino',
            snippet: widget.paquete.direccionDestino,
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueRed,
          ),
        ),
      );
    }

    // Marker de ubicación actual
    if (widget.ubicacionActual != null) {
      markers.add(
        Marker(
          markerId: const MarkerId('ubicacion_actual'),
          position: LatLng(
            widget.ubicacionActual!.latitude,
            widget.ubicacionActual!.longitude,
          ),
          infoWindow: const InfoWindow(
            title: 'Mi Ubicación',
            snippet: 'Ubicación actual del agente',
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueBlue,
          ),
        ),
      );
    }

    setState(() {
      _markers = markers;
    });
  }

  void _calcularDistancia() {
    if (widget.ubicacionActual != null &&
        widget.paquete.latitud != null &&
        widget.paquete.longitud != null) {
      final distancia = Geolocator.distanceBetween(
        widget.ubicacionActual!.latitude,
        widget.ubicacionActual!.longitude,
        widget.paquete.latitud!,
        widget.paquete.longitud!,
      );
      setState(() {
        _distancia = distancia;
      });
    }
  }

  void _centrarMapa() {
    if (_mapController != null &&
        widget.paquete.latitud != null &&
        widget.paquete.longitud != null) {
      _mapController!.animateCamera(
        CameraUpdate.newLatLngZoom(
          LatLng(
            widget.paquete.latitud!,
            widget.paquete.longitud!,
          ),
          15,
        ),
      );
    }
  }

  void _mostrarAmbosMarkers() {
    if (_mapController != null &&
        widget.ubicacionActual != null &&
        widget.paquete.latitud != null &&
        widget.paquete.longitud != null) {
      final bounds = LatLngBounds(
        southwest: LatLng(
          widget.ubicacionActual!.latitude < widget.paquete.latitud!
              ? widget.ubicacionActual!.latitude
              : widget.paquete.latitud!,
          widget.ubicacionActual!.longitude < widget.paquete.longitud!
              ? widget.ubicacionActual!.longitude
              : widget.paquete.longitud!,
        ),
        northeast: LatLng(
          widget.ubicacionActual!.latitude > widget.paquete.latitud!
              ? widget.ubicacionActual!.latitude
              : widget.paquete.latitud!,
          widget.ubicacionActual!.longitude > widget.paquete.longitud!
              ? widget.ubicacionActual!.longitude
              : widget.paquete.longitud!,
        ),
      );
      _mapController!.animateCamera(
        CameraUpdate.newLatLngBounds(bounds, 100),
      );
    }
  }

  String _formatearDistancia(double distancia) {
    if (distancia < 1000) {
      return '${distancia.toStringAsFixed(0)} m';
    } else {
      return '${(distancia / 1000).toStringAsFixed(2)} km';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.paquete.latitud == null || widget.paquete.longitud == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Ubicación'),
          backgroundColor: Colors.blue.shade700,
          foregroundColor: Colors.white,
        ),
        body: const Center(
          child: Text('Este paquete no tiene coordenadas de destino'),
        ),
      );
    }

    final destinoLatLng = LatLng(
      widget.paquete.latitud!,
      widget.paquete.longitud!,
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ubicación de Entrega'),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          // Fallback para web - Google Maps requiere API Key
          Container(
            color: Colors.grey.shade200,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.map,
                    size: 100,
                    color: Colors.grey.shade400,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Mapa no disponible en web',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey.shade700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Google Maps requiere API Key configurada',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: () {
                      // Abrir en Google Maps web
                      final url = 'https://www.google.com/maps/search/?api=1&query=${widget.paquete.latitud},${widget.paquete.longitud}';
                      // En producción usar url_launcher
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Abrir: $url'),
                          duration: const Duration(seconds: 5),
                        ),
                      );
                    },
                    icon: const Icon(Icons.open_in_new),
                    label: const Text('Abrir en Google Maps'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade700,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Información superior
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      widget.paquete.destinatario,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.paquete.direccionDestino,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey.shade700,
                      ),
                    ),
                    if (_distancia != null) ...[
                      const Divider(height: 16),
                      Row(
                        children: [
                          Icon(
                            Icons.straighten,
                            size: 16,
                            color: Colors.blue.shade700,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Distancia: ${_formatearDistancia(_distancia!)}',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.blue.shade700,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
          
          // Botones de control
          Positioned(
            bottom: 16,
            right: 16,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                FloatingActionButton(
                  heroTag: 'centrar',
                  onPressed: _centrarMapa,
                  backgroundColor: Colors.white,
                  child: Icon(
                    Icons.my_location,
                    color: Colors.blue.shade700,
                  ),
                ),
                if (widget.ubicacionActual != null) ...[
                  const SizedBox(height: 8),
                  FloatingActionButton(
                    heroTag: 'ambos',
                    onPressed: _mostrarAmbosMarkers,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.zoom_out_map,
                      color: Colors.blue.shade700,
                    ),
                  ),
                ],
              ],
            ),
          ),
          
          // Leyenda
          Positioned(
            bottom: 16,
            left: 16,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.location_on,
                          color: Colors.red.shade700,
                          size: 20,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Destino',
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                    if (widget.ubicacionActual != null) ...[
                      const SizedBox(height: 4),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.location_on,
                            color: Colors.blue.shade700,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          const Text(
                            'Mi ubicación',
                            style: TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
