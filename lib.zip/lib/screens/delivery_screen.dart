import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import '../models/paquete.dart';
import '../models/entrega.dart';
import '../services/auth_service.dart';
import '../services/location_service.dart';
import 'map_screen.dart';

class DeliveryScreen extends StatefulWidget {
  final Paquete paquete;
  final AuthService authService;

  const DeliveryScreen({
    super.key,
    required this.paquete,
    required this.authService,
  });

  @override
  State<DeliveryScreen> createState() => _DeliveryScreenState();
}

class _DeliveryScreenState extends State<DeliveryScreen> {
  final LocationService _locationService = LocationService();
  final ImagePicker _imagePicker = ImagePicker();
  final TextEditingController _observacionesController =
      TextEditingController();

  XFile? _fotoEvidencia;
  Position? _ubicacionActual;
  bool _isLoading = false;
  bool _obteniendoUbicacion = false;

  @override
  void initState() {
    super.initState();
    _obtenerUbicacion();
  }

  @override
  void dispose() {
    _observacionesController.dispose();
    super.dispose();
  }

  Future<void> _obtenerUbicacion() async {
    setState(() {
      _obteniendoUbicacion = true;
    });

    try {
      final position = await _locationService.obtenerUbicacionActual();
      setState(() {
        _ubicacionActual = position;
        _obteniendoUbicacion = false;
      });
    } catch (e) {
      setState(() {
        _obteniendoUbicacion = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al obtener ubicación: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _tomarFoto() async {
    try {
      final XFile? foto = await _imagePicker.pickImage(
        source: ImageSource.camera,
        maxWidth: 1920,
        maxHeight: 1080,
        imageQuality: 85,
      );

      if (foto != null) {
        setState(() {
          _fotoEvidencia = foto;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al capturar foto: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _seleccionarFotoGaleria() async {
    try {
      final XFile? foto = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1920,
        maxHeight: 1080,
        imageQuality: 85,
      );

      if (foto != null) {
        setState(() {
          _fotoEvidencia = foto;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al seleccionar foto: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _mostrarOpcionesFoto() {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Tomar foto'),
              onTap: () {
                Navigator.pop(context);
                _tomarFoto();
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Seleccionar de galería'),
              onTap: () {
                Navigator.pop(context);
                _seleccionarFotoGaleria();
              },
            ),
            if (_fotoEvidencia != null)
              ListTile(
                leading: const Icon(Icons.delete, color: Colors.red),
                title: const Text('Eliminar foto'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _fotoEvidencia = null;
                  });
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmarEntrega() async {
    // Validaciones
    if (_fotoEvidencia == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Debe capturar una foto de evidencia'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    if (_ubicacionActual == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Debe obtener la ubicación GPS'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    // Confirmar con el usuario
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar Entrega'),
        content: const Text(
          '¿Está seguro de confirmar la entrega de este paquete? '
          'Esta acción no se puede deshacer.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
            ),
            child: const Text('Confirmar'),
          ),
        ],
      ),
    );

    if (confirmar != true) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final usuario = widget.authService.usuarioActual;
      if (usuario == null) {
        throw Exception('Usuario no autenticado');
      }

      // Subir foto
      String? fotoUrl;
      if (_fotoEvidencia != null) {
        if (kIsWeb) {
          // Para web, leer los bytes
          final bytes = await _fotoEvidencia!.readAsBytes();
          fotoUrl = await widget.authService.apiService
              .subirFotoEvidencia(bytes, widget.paquete.id);
        } else {
          // Para móvil, usar el path
          fotoUrl = await widget.authService.apiService
              .subirFotoEvidencia(_fotoEvidencia!.path, widget.paquete.id);
        }
      }

      // Crear objeto de entrega
      final entrega = Entrega(
        paqueteId: widget.paquete.id,
        agenteId: usuario.id,
        fechaEntrega: DateTime.now().toIso8601String(),
        latitudEntrega: _ubicacionActual!.latitude,
        longitudEntrega: _ubicacionActual!.longitude,
        fotoEvidencia: fotoUrl,
        observaciones: _observacionesController.text.trim().isEmpty
            ? null
            : _observacionesController.text.trim(),
      );

      // Registrar entrega
      await widget.authService.apiService.registrarEntrega(entrega);

      // Actualizar estado del paquete
      await widget.authService.apiService
          .actualizarEstadoPaquete(widget.paquete.id, 'entregado');

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Entrega registrada exitosamente'),
            backgroundColor: Colors.green,
          ),
        );

        // Regresar a la pantalla anterior
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al registrar entrega: $e'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _verMapa() {
    if (widget.paquete.latitud != null && widget.paquete.longitud != null) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => MapScreen(
            paquete: widget.paquete,
            ubicacionActual: _ubicacionActual,
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Este paquete no tiene coordenadas de destino'),
          backgroundColor: Colors.orange,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Entrega de Paquete'),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
      ),
      body: _isLoading
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Registrando entrega...'),
                ],
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Información del paquete
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.inventory_2,
                                color: Colors.blue.shade700,
                                size: 32,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      'Información del Paquete',
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      widget.paquete.numeroRastreo,
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 24),
                          _buildInfoRow(
                            'Destinatario',
                            widget.paquete.destinatario,
                            Icons.person,
                          ),
                          const SizedBox(height: 8),
                          _buildInfoRow(
                            'Dirección',
                            widget.paquete.direccionDestino,
                            Icons.location_on,
                          ),
                          if (widget.paquete.descripcion != null) ...[
                            const SizedBox(height: 8),
                            _buildInfoRow(
                              'Descripción',
                              widget.paquete.descripcion!,
                              Icons.description,
                            ),
                          ],
                          if (widget.paquete.peso != null) ...[
                            const SizedBox(height: 8),
                            _buildInfoRow(
                              'Peso',
                              '${widget.paquete.peso} kg',
                              Icons.scale,
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Ubicación GPS
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.gps_fixed,
                                    color: _ubicacionActual != null
                                        ? Colors.green
                                        : Colors.grey,
                                  ),
                                  const SizedBox(width: 8),
                                  const Text(
                                    'Ubicación GPS',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              if (!_obteniendoUbicacion)
                                IconButton(
                                  icon: const Icon(Icons.refresh),
                                  onPressed: _obtenerUbicacion,
                                  tooltip: 'Actualizar ubicación',
                                ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          if (_obteniendoUbicacion)
                            const Center(
                              child: Padding(
                                padding: EdgeInsets.all(16),
                                child: CircularProgressIndicator(),
                              ),
                            )
                          else if (_ubicacionActual != null)
                            Column(
                              children: [
                                _buildInfoRow(
                                  'Latitud',
                                  _ubicacionActual!.latitude
                                      .toStringAsFixed(6),
                                  Icons.south,
                                ),
                                const SizedBox(height: 8),
                                _buildInfoRow(
                                  'Longitud',
                                  _ubicacionActual!.longitude
                                      .toStringAsFixed(6),
                                  Icons.east,
                                ),
                                if (widget.paquete.latitud != null &&
                                    widget.paquete.longitud != null) ...[
                                  const SizedBox(height: 12),
                                  ElevatedButton.icon(
                                    onPressed: _verMapa,
                                    icon: const Icon(Icons.map),
                                    label: const Text('Ver en Mapa'),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue.shade700,
                                      foregroundColor: Colors.white,
                                    ),
                                  ),
                                ],
                              ],
                            )
                          else
                            const Center(
                              child: Padding(
                                padding: EdgeInsets.all(16),
                                child: Text(
                                  'No se pudo obtener la ubicación',
                                  style: TextStyle(color: Colors.red),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Foto de evidencia
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.camera_alt,
                                color: _fotoEvidencia != null
                                    ? Colors.green
                                    : Colors.grey,
                              ),
                              const SizedBox(width: 8),
                              const Text(
                                'Foto de Evidencia',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          if (_fotoEvidencia != null)
                            Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: kIsWeb
                                      ? Image.network(
                                          _fotoEvidencia!.path,
                                          height: 200,
                                          width: double.infinity,
                                          fit: BoxFit.cover,
                                          errorBuilder: (context, error, stackTrace) {
                                            return Container(
                                              height: 200,
                                              color: Colors.grey.shade300,
                                              child: const Center(
                                                child: Icon(Icons.image, size: 50),
                                              ),
                                            );
                                          },
                                        )
                                      : Image.file(
                                          File(_fotoEvidencia!.path),
                                          height: 200,
                                          width: double.infinity,
                                          fit: BoxFit.cover,
                                        ),
                                ),
                                const SizedBox(height: 8),
                              ],
                            ),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: _mostrarOpcionesFoto,
                              icon: Icon(_fotoEvidencia != null
                                  ? Icons.edit
                                  : Icons.camera_alt),
                              label: Text(_fotoEvidencia != null
                                  ? 'Cambiar Foto'
                                  : 'Capturar Foto'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _fotoEvidencia != null
                                    ? Colors.orange
                                    : Colors.blue.shade700,
                                foregroundColor: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Observaciones
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.notes,
                                color: Colors.grey.shade700,
                              ),
                              const SizedBox(width: 8),
                              const Text(
                                'Observaciones (Opcional)',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _observacionesController,
                            maxLines: 3,
                            decoration: InputDecoration(
                              hintText:
                                  'Ingrese cualquier observación sobre la entrega...',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Botón de confirmar entrega
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      onPressed: _confirmarEntrega,
                      icon: const Icon(Icons.check_circle, size: 24),
                      label: const Text(
                        'PAQUETE ENTREGADO',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 4,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
    );
  }

  Widget _buildInfoRow(String label, String value, IconData icon) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 20, color: Colors.grey.shade600),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
