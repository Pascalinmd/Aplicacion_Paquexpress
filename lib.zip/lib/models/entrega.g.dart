// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entrega.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Entrega _$EntregaFromJson(Map<String, dynamic> json) => Entrega(
  id: (json['id'] as num?)?.toInt(),
  paqueteId: (json['paquete_id'] as num).toInt(),
  agenteId: (json['agente_id'] as num).toInt(),
  fechaEntrega: json['fecha_entrega'] as String,
  latitudEntrega: (json['latitud_entrega'] as num).toDouble(),
  longitudEntrega: (json['longitud_entrega'] as num).toDouble(),
  fotoEvidencia: json['foto_evidencia'] as String?,
  observaciones: json['observaciones'] as String?,
);

Map<String, dynamic> _$EntregaToJson(Entrega instance) => <String, dynamic>{
  'id': instance.id,
  'paquete_id': instance.paqueteId,
  'agente_id': instance.agenteId,
  'fecha_entrega': instance.fechaEntrega,
  'latitud_entrega': instance.latitudEntrega,
  'longitud_entrega': instance.longitudEntrega,
  'foto_evidencia': instance.fotoEvidencia,
  'observaciones': instance.observaciones,
};
