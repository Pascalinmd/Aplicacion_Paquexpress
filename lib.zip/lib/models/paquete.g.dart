// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'paquete.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Paquete _$PaqueteFromJson(Map<String, dynamic> json) => Paquete(
  id: (json['id'] as num).toInt(),
  numeroRastreo: json['numero_rastreo'] as String,
  destinatario: json['destinatario'] as String,
  direccionDestino: json['direccion_destino'] as String,
  latitud: (json['latitud'] as num?)?.toDouble(),
  longitud: (json['longitud'] as num?)?.toDouble(),
  estado: json['estado'] as String,
  agenteId: (json['agente_id'] as num?)?.toInt(),
  fechaAsignacion: json['fecha_asignacion'] as String?,
  fechaEntrega: json['fecha_entrega'] as String?,
  descripcion: json['descripcion'] as String?,
  peso: (json['peso'] as num?)?.toDouble(),
);

Map<String, dynamic> _$PaqueteToJson(Paquete instance) => <String, dynamic>{
  'id': instance.id,
  'numero_rastreo': instance.numeroRastreo,
  'destinatario': instance.destinatario,
  'direccion_destino': instance.direccionDestino,
  'latitud': instance.latitud,
  'longitud': instance.longitud,
  'estado': instance.estado,
  'agente_id': instance.agenteId,
  'fecha_asignacion': instance.fechaAsignacion,
  'fecha_entrega': instance.fechaEntrega,
  'descripcion': instance.descripcion,
  'peso': instance.peso,
};
