import 'package:json_annotation/json_annotation.dart';

part 'entrega.g.dart';

@JsonSerializable()
class Entrega {
  final int? id;
  @JsonKey(name: 'paquete_id')
  final int paqueteId;
  @JsonKey(name: 'agente_id')
  final int agenteId;
  @JsonKey(name: 'fecha_entrega')
  final String fechaEntrega;
  @JsonKey(name: 'latitud_entrega')
  final double latitudEntrega;
  @JsonKey(name: 'longitud_entrega')
  final double longitudEntrega;
  @JsonKey(name: 'foto_evidencia')
  final String? fotoEvidencia; // Base64 o URL
  final String? observaciones;

  Entrega({
    this.id,
    required this.paqueteId,
    required this.agenteId,
    required this.fechaEntrega,
    required this.latitudEntrega,
    required this.longitudEntrega,
    this.fotoEvidencia,
    this.observaciones,
  });

  factory Entrega.fromJson(Map<String, dynamic> json) => _$EntregaFromJson(json);
  Map<String, dynamic> toJson() => _$EntregaToJson(this);
}
