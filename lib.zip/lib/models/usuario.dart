import 'package:json_annotation/json_annotation.dart';

part 'usuario.g.dart';

@JsonSerializable()
class Usuario {
  final int id;
  final String username;
  final String nombre;
  final String apellido;
  final String email;
  final String? token;

  Usuario({
    required this.id,
    required this.username,
    required this.nombre,
    required this.apellido,
    required this.email,
    this.token,
  });

  factory Usuario.fromJson(Map<String, dynamic> json) => _$UsuarioFromJson(json);
  Map<String, dynamic> toJson() => _$UsuarioToJson(this);

  Usuario copyWith({
    int? id,
    String? username,
    String? nombre,
    String? apellido,
    String? email,
    String? token,
  }) {
    return Usuario(
      id: id ?? this.id,
      username: username ?? this.username,
      nombre: nombre ?? this.nombre,
      apellido: apellido ?? this.apellido,
      email: email ?? this.email,
      token: token ?? this.token,
    );
  }
}
