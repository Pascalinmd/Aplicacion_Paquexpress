import 'package:json_annotation/json_annotation.dart';

part 'paquete.g.dart';

@JsonSerializable()
class Paquete {
  final int id;
  @JsonKey(name: 'numero_rastreo')
  final String numeroRastreo;
  final String destinatario;
  @JsonKey(name: 'direccion_destino')
  final String direccionDestino;
  final double? latitud;
  final double? longitud;
  final String estado; // 'pendiente', 'en_transito', 'entregado'
  @JsonKey(name: 'agente_id')
  final int? agenteId;
  @JsonKey(name: 'fecha_asignacion')
  final String? fechaAsignacion;
  @JsonKey(name: 'fecha_entrega')
  final String? fechaEntrega;
  final String? descripcion;
  final double? peso;

  Paquete({
    required this.id,
    required this.numeroRastreo,
    required this.destinatario,
    required this.direccionDestino,
    this.latitud,
    this.longitud,
    required this.estado,
    this.agenteId,
    this.fechaAsignacion,
    this.fechaEntrega,
    this.descripcion,
    this.peso,
  });

  factory Paquete.fromJson(Map<String, dynamic> json) => _$PaqueteFromJson(json);
  Map<String, dynamic> toJson() => _$PaqueteToJson(this);

  bool get esPendiente => estado == 'pendiente' || estado == 'en_transito';
  bool get estaEntregado => estado == 'entregado';
}
