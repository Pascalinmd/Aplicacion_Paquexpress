import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../models/usuario.dart';
import 'api_service.dart';
import 'dart:convert';

class AuthService {
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final ApiService _apiService = ApiService();
  
  Usuario? _usuarioActual;
  
  Usuario? get usuarioActual => _usuarioActual;
  bool get estaAutenticado => _usuarioActual != null;

  // Login
  Future<Usuario> login(String username, String password) async {
    try {
      final response = await _apiService.login(username, password);
      
      final usuario = Usuario(
        id: response['user']['id'],
        username: response['user']['username'],
        nombre: response['user']['nombre'],
        apellido: response['user']['apellido'],
        email: response['user']['email'],
        token: response['access_token'],
      );

      // Guardar token y datos del usuario
      await _storage.write(key: 'token', value: response['access_token']);
      await _storage.write(key: 'usuario', value: jsonEncode(usuario.toJson()));
      
      _apiService.setToken(response['access_token']);
      _usuarioActual = usuario;
      
      return usuario;
    } catch (e) {
      throw Exception('Error en login: $e');
    }
  }

  // Logout
  Future<void> logout() async {
    await _storage.delete(key: 'token');
    await _storage.delete(key: 'usuario');
    _usuarioActual = null;
  }

  // Cargar sesión guardada
  Future<bool> cargarSesion() async {
    try {
      final token = await _storage.read(key: 'token');
      final usuarioJson = await _storage.read(key: 'usuario');
      
      if (token != null && usuarioJson != null) {
        _usuarioActual = Usuario.fromJson(jsonDecode(usuarioJson));
        _apiService.setToken(token);
        return true;
      }
      return false;
    } catch (e) {
      await logout();
      return false;
    }
  }

  // Obtener token
  Future<String?> obtenerToken() async {
    return await _storage.read(key: 'token');
  }

  // Verificar si el token es válido
  Future<bool> validarToken() async {
    final token = await obtenerToken();
    if (token == null) return false;
    
    // Aquí podrías hacer una llamada al backend para verificar el token
    // Por ahora solo verificamos que exista
    return true;
  }

  ApiService get apiService => _apiService;
}
