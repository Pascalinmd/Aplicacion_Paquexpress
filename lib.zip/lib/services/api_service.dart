import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import '../models/paquete.dart';
import '../models/entrega.dart';

class ApiService {
  // Cambia esta URL por la IP de tu servidor FastAPI
  // static const String baseUrl = 'http://10.0.2.2:8000'; // Para emulador Android
  static const String baseUrl = 'http://localhost:8000'; // Para web/desktop
  // static const String baseUrl = 'http://TU_IP:8000'; // Para dispositivo físico
  
  String? _token;

  void setToken(String token) {
    _token = token;
  }

  Map<String, String> _getHeaders() {
    final headers = {
      'Content-Type': 'application/json',
    };
    if (_token != null) {
      headers['Authorization'] = 'Bearer $_token';
    }
    return headers;
  }

  // Autenticación
  Future<Map<String, dynamic>> login(String username, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Error de autenticación: ${response.body}');
      }
    } catch (e) {
      throw Exception('Error de conexión: $e');
    }
  }

  // Obtener paquetes asignados al agente
  Future<List<Paquete>> obtenerPaquetesAsignados(int agenteId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/paquetes/agente/$agenteId'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Paquete.fromJson(json)).toList();
      } else {
        throw Exception('Error al obtener paquetes: ${response.body}');
      }
    } catch (e) {
      throw Exception('Error de conexión: $e');
    }
  }

  // Obtener un paquete específico
  Future<Paquete> obtenerPaquete(int paqueteId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/paquetes/$paqueteId'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        return Paquete.fromJson(jsonDecode(response.body));
      } else {
        throw Exception('Error al obtener paquete: ${response.body}');
      }
    } catch (e) {
      throw Exception('Error de conexión: $e');
    }
  }

  // Registrar entrega de paquete
  Future<Map<String, dynamic>> registrarEntrega(Entrega entrega) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/entregas'),
        headers: _getHeaders(),
        body: jsonEncode(entrega.toJson()),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Error al registrar entrega: ${response.body}');
      }
    } catch (e) {
      throw Exception('Error de conexión: $e');
    }
  }

  // Subir foto de evidencia
  Future<String> subirFotoEvidencia(dynamic imageSource, int paqueteId) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/api/entregas/upload-foto'),
      );
      
      request.headers.addAll(_getHeaders());
      
      if (kIsWeb) {
        // Para web, imageSource debe ser bytes
        if (imageSource is List<int>) {
          request.files.add(http.MultipartFile.fromBytes(
            'file',
            imageSource,
            filename: 'evidencia_${DateTime.now().millisecondsSinceEpoch}.jpg',
            contentType: MediaType('image', 'jpeg'),
          ));
        } else {
          throw Exception('En web se requieren bytes de la imagen');
        }
      } else {
        // Para móvil, imageSource es el path
        request.files.add(await http.MultipartFile.fromPath(
          'file',
          imageSource,
          contentType: MediaType('image', 'jpeg'),
        ));
      }
      
      request.fields['paquete_id'] = paqueteId.toString();

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['url'] ?? data['filename'];
      } else {
        throw Exception('Error al subir foto: ${response.body}');
      }
    } catch (e) {
      throw Exception('Error al subir foto: $e');
    }
  }

  // Actualizar estado del paquete
  Future<void> actualizarEstadoPaquete(int paqueteId, String estado) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/api/paquetes/$paqueteId/estado'),
        headers: _getHeaders(),
        body: jsonEncode({'estado': estado}),
      );

      if (response.statusCode != 200) {
        throw Exception('Error al actualizar estado: ${response.body}');
      }
    } catch (e) {
      throw Exception('Error de conexión: $e');
    }
  }
}
